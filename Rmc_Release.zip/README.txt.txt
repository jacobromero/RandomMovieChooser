To use this program, unzip the release folder to any location to your computer
then use RMC#.exe to run the program.
you can right click RMC#.exe to create a shortcut, you can put on your desktop if you would like.